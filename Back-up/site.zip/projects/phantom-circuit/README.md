This demonstrates a GoJS diagram rendered by PhantomJS on a server.

First, assuming you already have npm and git:
```
$ npm install gojs
$ npm install phantomjs
```

Run app with:
```
$ node_modules/.bin/phantomjs logicCircuit.js
```
