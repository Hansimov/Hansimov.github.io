This demonstrates a GoJS diagram in an Electron app.

First, assuming you already have npm and git:
```
$ npm install gojs
$ npm install electron-prebuilt
```

Start app with:
```
$ node_modules/.bin/electron .
```
